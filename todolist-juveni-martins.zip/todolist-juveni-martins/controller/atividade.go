package controller

import (
	"fmt"
	"log"
	"todolist-juveni-martins/model"

	"github.com/labstack/echo"
)

func GetAtividades() interface{} {
	atvs, err := model.GetAll()
	if err != nil {
		fmt.Println(err)
	}
	return atvs
}

func GetAtividadeById(id string) []model.Atividade {
	atividade, err := model.GetById(id)
	if err != nil {
		fmt.Println(err)
	}
	return atividade
}

func SaveAtividade(c echo.Context) error {
	a := new(model.Atividade)
	err := c.Bind(a)
	if err != nil {
		return err
	}
	err2 := model.UpdateAtividade(a)
	log.Println(err.Error())
	return err2
}
