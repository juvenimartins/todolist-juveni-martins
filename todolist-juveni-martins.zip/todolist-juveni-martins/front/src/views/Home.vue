<template>
    <q-page>
      <q-list link>
        <q-list-header>Lista de Atividades</q-list-header>
        <q-item v-for="atividade in atividades" :key="atividade.id">
          <q-item-main>
            <q-btn icon="description" @click="nova = true" />
            <q-item-tile label>{{atividade.titulo}}</q-item-tile>
            <q-item-tile sublabel>{{atividade.descricao}}</q-item-tile>
          </q-item-main>
        </q-item>
      </q-list>
      <q-modal maximized v-model="detalhes" :content-css="{padding: '50px'}">
        <q-btn color="primary" @click="detalhes = false" label="Close" />
        <div v-for="a in atividadesDetalhes" :key="a.id">
          <h4>{{a.titulo}}</h4>
          <p>{{a.descricao}}</p>
        </div>
      </q-modal>
      <q-modal maximized v-model="nova" :content-css="{padding: '50px'}">
        <q-icon name="close" @click="nova = false" />
        <q-datetime v-model="data_atividade" type="date" float-label="Data"/>
        <q-input v-model="titulo" float-label="Titulo"/>
        <q-input v-model="descricao" type="textarea" :max-height="100" :min-rows="7" float-label="Descrição"/>
        <q-btn color="secondary" @click="onInsert()" label="Cadastrar" />
      </q-modal>
    </q-page>
</template>
<style>
</style>
<script>
/* eslint-disable */
import axios from 'axios'

let url = "http://localhost:8000"
export default {
  name: 'PageHome',
  data () {
    return{
      atividades : null,
      atividadesDetalhes: null,
      detalhes: false,
      nova: false,
      titulo: '',
      descricao: '',
      data_atividade: '',
    } 
  },
  created () {
      axios.get(url+'/atividade').then(r => {
      this.atividades = r.data
    })
  },
  methods: {
    onShow(id) {
      this.detalhes = true
      axios.get(url+'/show?id='+id).then(r => {
        this.atividadesDetalhes = r.data
      })
    },
    onInsert(){ 
      const formData = new FormData()
      formData.append('data', this.data_atividade)
      formData.append('titulo', this.titulo)
      formData.append("descricao", this.descricao)

      axios.post(url+'/insert', formData).then(r => {
        console.log(r.data)
      })
    }
  }
}
//this.nova = true      
      // let data = {
      //   "data" : this.data_atividade,
      //   "titulo" : this.titulo,
      //   "descricao" : this.descricao,
      // }
      // console.log(data)
</script>