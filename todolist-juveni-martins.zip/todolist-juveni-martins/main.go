package main

import (
	"net/http"
	"todolist-juveni-martins/controller"

	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
)

type User struct {
	Name  string `json:"name" xml:"name" form:"name" query:"name"`
	Email string `json:"email" xml:"email" form:"email" query:"email"`
}

func show(c echo.Context) error {
	// Get team and member from the query string
	id := c.QueryParam("id")
	return c.JSON(http.StatusOK, controller.GetAtividadeById(id))
}

func save(c echo.Context) error {
	if err := controller.SaveAtividade(c); err != nil {
		return err
	}
	return c.String(http.StatusCreated, "status:ok")
}

func main() {
	e := echo.New()
	e.Use(middleware.CORS())

	// Lista Atividades
	e.GET("/atividade", func(c echo.Context) error {
		return c.JSON(http.StatusCreated, controller.GetAtividades())
	})
	e.GET("/show", show)
	e.POST("/insert", save)

	// e.GET("/atividade/:id", func(c echo.Context) error {
	// 	id := parseInt(c.QueryParam("id"))
	// 	return c.JSON(http.StatusCreated, id)
	// })

	e.Logger.Fatal(e.Start(":1323"))
}
